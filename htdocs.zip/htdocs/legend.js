// legend.js
export const tailwindLegend = [
  // Layout
  {
    tw: 'block',
    css: { display: 'block' }
  },
  {
    tw: 'inline-block',
    css: { display: 'inline-block' }
  },
  {
    tw: 'inline',
    css: { display: 'inline' }
  },
  {
    tw: 'flex',
    css: { display: 'flex' }
  },
  {
    tw: 'inline-flex',
    css: { display: 'inline-flex' }
  },
  {
    tw: 'grid',
    css: { display: 'grid' }
  },
  {
    tw: 'inline-grid',
    css: { display: 'inline-grid' }
  },
  {
    tw: 'hidden',
    css: { display: 'none' }
  },

  // Flexbox
  {
    tw: 'flex-row',
    css: { flexDirection: 'row' }
  },
  {
    tw: 'flex-row-reverse',
    css: { flexDirection: 'row-reverse' }
  },
  {
    tw: 'flex-col',
    css: { flexDirection: 'column' }
  },
  {
    tw: 'flex-col-reverse',
    css: { flexDirection: 'column-reverse' }
  },
  {
    tw: 'flex-wrap',
    css: { flexWrap: 'wrap' }
  },
  {
    tw: 'flex-wrap-reverse',
    css: { flexWrap: 'wrap-reverse' }
  },
  {
    tw: 'flex-nowrap',
    css: { flexWrap: 'nowrap' }
  },
  {
    tw: 'flex-1',
    css: { flex: '1 1 0%' }
  },
  {
    tw: 'flex-auto',
    css: { flex: '1 1 auto' }
  },
  {
    tw: 'flex-initial',
    css: { flex: '0 1 auto' }
  },
  {
    tw: 'flex-none',
    css: { flex: 'none' }
  },
  {
    tw: 'justify-start',
    css: { justifyContent: 'flex-start' }
  },
  {
    tw: 'justify-end',
    css: { justifyContent: 'flex-end' }
  },
  {
    tw: 'justify-center',
    css: { justifyContent: 'center' }
  },
  {
    tw: 'justify-between',
    css: { justifyContent: 'space-between' }
  },
  {
    tw: 'justify-around',
    css: { justifyContent: 'space-around' }
  },
  {
    tw: 'justify-evenly',
    css: { justifyContent: 'space-evenly' }
  },
  {
    tw: 'items-start',
    css: { alignItems: 'flex-start' }
  },
  {
    tw: 'items-end',
    css: { alignItems: 'flex-end' }
  },
  {
    tw: 'items-center',
    css: { alignItems: 'center' }
  },
  {
    tw: 'items-baseline',
    css: { alignItems: 'baseline' }
  },
  {
    tw: 'items-stretch',
    css: { alignItems: 'stretch' }
  },
  {
    tw: 'self-auto',
    css: { alignSelf: 'auto' }
  },
  {
    tw: 'self-start',
    css: { alignSelf: 'flex-start' }
  },
  {
    tw: 'self-end',
    css: { alignSelf: 'flex-end' }
  },
  {
    tw: 'self-center',
    css: { alignSelf: 'center' }
  },
  {
    tw: 'self-stretch',
    css: { alignSelf: 'stretch' }
  },

  // Grid
  {
    tw: 'grid-cols-1',
    css: { gridTemplateColumns: 'repeat(1, minmax(0, 1fr))' }
  },
  {
    tw: 'grid-cols-2',
    css: { gridTemplateColumns: 'repeat(2, minmax(0, 1fr))' }
  },
  {
    tw: 'grid-cols-3',
    css: { gridTemplateColumns: 'repeat(3, minmax(0, 1fr))' }
  },
  {
    tw: 'grid-cols-4',
    css: { gridTemplateColumns: 'repeat(4, minmax(0, 1fr))' }
  },
  {
    tw: 'grid-cols-5',
    css: { gridTemplateColumns: 'repeat(5, minmax(0, 1fr))' }
  },
  {
    tw: 'grid-cols-6',
    css: { gridTemplateColumns: 'repeat(6, minmax(0, 1fr))' }
  },
  {
    tw: 'grid-cols-7',
    css: { gridTemplateColumns: 'repeat(7, minmax(0, 1fr))' }
  },
  {
    tw: 'grid-cols-8',
    css: { gridTemplateColumns: 'repeat(8, minmax(0, 1fr))' }
  },
  {
    tw: 'grid-cols-9',
    css: { gridTemplateColumns: 'repeat(9, minmax(0, 1fr))' }
  },
  {
    tw: 'grid-cols-10',
    css: { gridTemplateColumns: 'repeat(10, minmax(0, 1fr))' }
  },
  {
    tw: 'grid-cols-11',
    css: { gridTemplateColumns: 'repeat(11, minmax(0, 1fr))' }
  },
  {
    tw: 'grid-cols-12',
    css: { gridTemplateColumns: 'repeat(12, minmax(0, 1fr))' }
  },
  {
    tw: 'col-span-1',
    css: { gridColumn: 'span 1 / span 1' }
  },
  {
    tw: 'col-span-2',
    css: { gridColumn: 'span 2 / span 2' }
  },
  {
    tw: 'col-span-3',
    css: { gridColumn: 'span 3 / span 3' }
  },
  {
    tw: 'col-span-4',
    css: { gridColumn: 'span 4 / span 4' }
  },
  {
    tw: 'col-span-5',
    css: { gridColumn: 'span 5 / span 5' }
  },
  {
    tw: 'col-span-6',
    css: { gridColumn: 'span 6 / span 6' }
  },
  {
    tw: 'col-span-7',
    css: { gridColumn: 'span 7 / span 7' }
  },
  {
    tw: 'col-span-8',
    css: { gridColumn: 'span 8 / span 8' }
  },
  {
    tw: 'col-span-9',
    css: { gridColumn: 'span 9 / span 9' }
  },
  {
    tw: 'col-span-10',
    css: { gridColumn: 'span 10 / span 10' }
  },
  {
    tw: 'col-span-11',
    css: { gridColumn: 'span 11 / span 11' }
  },
  {
    tw: 'col-span-12',
    css: { gridColumn: 'span 12 / span 12' }
  },
  {
    tw: 'col-span-full',
    css: { gridColumn: '1 / -1' }
  },

  // Spacing (Padding & Margin)
  {
    tw: 'p-0',
    css: { padding: '0px' }
  },
  {
    tw: 'p-1',
    css: { padding: '0.25rem' }
  },
  {
    tw: 'p-2',
    css: { padding: '0.5rem' }
  },
  {
    tw: 'p-3',
    css: { padding: '0.75rem' }
  },
  {
    tw: 'p-4',
    css: { padding: '1rem' }
  },
  {
    tw: 'p-5',
    css: { padding: '1.25rem' }
  },
  {
    tw: 'p-6',
    css: { padding: '1.5rem' }
  },
  {
    tw: 'p-8',
    css: { padding: '2rem' }
  },
  {
    tw: 'p-10',
    css: { padding: '2.5rem' }
  },
  {
    tw: 'p-12',
    css: { padding: '3rem' }
  },
  {
    tw: 'p-16',
    css: { padding: '4rem' }
  },
  {
    tw: 'p-20',
    css: { padding: '5rem' }
  },
  {
    tw: 'p-24',
    css: { padding: '6rem' }
  },
  {
    tw: 'px-0',
    css: { paddingLeft: '0px', paddingRight: '0px' }
  },
  {
    tw: 'px-1',
    css: { paddingLeft: '0.25rem', paddingRight: '0.25rem' }
  },
  {
    tw: 'px-2',
    css: { paddingLeft: '0.5rem', paddingRight: '0.5rem' }
  },
  {
    tw: 'px-3',
    css: { paddingLeft: '0.75rem', paddingRight: '0.75rem' }
  },
  {
    tw: 'px-4',
    css: { paddingLeft: '1rem', paddingRight: '1rem' }
  },
  {
    tw: 'px-5',
    css: { paddingLeft: '1.25rem', paddingRight: '1.25rem' }
  },
  {
    tw: 'px-6',
    css: { paddingLeft: '1.5rem', paddingRight: '1.5rem' }
  },
  {
    tw: 'py-0',
    css: { paddingTop: '0px', paddingBottom: '0px' }
  },
  {
    tw: 'py-1',
    css: { paddingTop: '0.25rem', paddingBottom: '0.25rem' }
  },
  {
    tw: 'py-2',
    css: { paddingTop: '0.5rem', paddingBottom: '0.5rem' }
  },
  {
    tw: 'py-3',
    css: { paddingTop: '0.75rem', paddingBottom: '0.75rem' }
  },
  {
    tw: 'py-4',
    css: { paddingTop: '1rem', paddingBottom: '1rem' }
  },
  {
    tw: 'py-5',
    css: { paddingTop: '1.25rem', paddingBottom: '1.25rem' }
  },
  {
    tw: 'py-6',
    css: { paddingTop: '1.5rem', paddingBottom: '1.5rem' }
  },
  {
    tw: 'pt-0',
    css: { paddingTop: '0px' }
  },
  {
    tw: 'pt-1',
    css: { paddingTop: '0.25rem' }
  },
  {
    tw: 'pt-2',
    css: { paddingTop: '0.5rem' }
  },
  {
    tw: 'pt-3',
    css: { paddingTop: '0.75rem' }
  },
  {
    tw: 'pt-4',
    css: { paddingTop: '1rem' }
  },
  {
    tw: 'pr-0',
    css: { paddingRight: '0px' }
  },
  {
    tw: 'pr-1',
    css: { paddingRight: '0.25rem' }
  },
  {
    tw: 'pr-2',
    css: { paddingRight: '0.5rem' }
  },
  {
    tw: 'pr-3',
    css: { paddingRight: '0.75rem' }
  },
  {
    tw: 'pr-4',
    css: { paddingRight: '1rem' }
  },
  {
    tw: 'pb-0',
    css: { paddingBottom: '0px' }
  },
  {
    tw: 'pb-1',
    css: { paddingBottom: '0.25rem' }
  },
  {
    tw: 'pb-2',
    css: { paddingBottom: '0.5rem' }
  },
  {
    tw: 'pb-3',
    css: { paddingBottom: '0.75rem' }
  },
  {
    tw: 'pb-4',
    css: { paddingBottom: '1rem' }
  },
  {
    tw: 'pl-0',
    css: { paddingLeft: '0px' }
  },
  {
    tw: 'pl-1',
    css: { paddingLeft: '0.25rem' }
  },
  {
    tw: 'pl-2',
    css: { paddingLeft: '0.5rem' }
  },
  {
    tw: 'pl-3',
    css: { paddingLeft: '0.75rem' }
  },
  {
    tw: 'pl-4',
    css: { paddingLeft: '1rem' }
  },

  // Margin (similar pattern to padding)
  {
    tw: 'm-0',
    css: { margin: '0px' }
  },
  {
    tw: 'm-1',
    css: { margin: '0.25rem' }
  },
  {
    tw: 'm-2',
    css: { margin: '0.5rem' }
  },
  {
    tw: 'm-3',
    css: { margin: '0.75rem' }
  },
  {
    tw: 'm-4',
    css: { margin: '1rem' }
  },
  {
    tw: 'mx-0',
    css: { marginLeft: '0px', marginRight: '0px' }
  },
  {
    tw: 'mx-1',
    css: { marginLeft: '0.25rem', marginRight: '0.25rem' }
  },
  {
    tw: 'mx-2',
    css: { marginLeft: '0.5rem', marginRight: '0.5rem' }
  },
  {
    tw: 'mx-3',
    css: { marginLeft: '0.75rem', marginRight: '0.75rem' }
  },
  {
    tw: 'mx-4',
    css: { marginLeft: '1rem', marginRight: '1rem' }
  },
  {
    tw: 'my-0',
    css: { marginTop: '0px', marginBottom: '0px' }
  },
  {
    tw: 'my-1',
    css: { marginTop: '0.25rem', marginBottom: '0.25rem' }
  },
  {
    tw: 'my-2',
    css: { marginTop: '0.5rem', marginBottom: '0.5rem' }
  },
  {
    tw: 'my-3',
    css: { marginTop: '0.75rem', marginBottom: '0.75rem' }
  },
  {
    tw: 'my-4',
    css: { marginTop: '1rem', marginBottom: '1rem' }
  },

  // Width
  {
    tw: 'w-0',
    css: { width: '0px' }
  },
  {
    tw: 'w-1',
    css: { width: '0.25rem' }
  },
  {
    tw: 'w-2',
    css: { width: '0.5rem' }
  },
  {
    tw: 'w-3',
    css: { width: '0.75rem' }
  },
  {
    tw: 'w-4',
    css: { width: '1rem' }
  },
  {
    tw: 'w-5',
    css: { width: '1.25rem' }
  },
  {
    tw: 'w-6',
    css: { width: '1.5rem' }
  },
  {
    tw: 'w-8',
    css: { width: '2rem' }
  },
  {
    tw: 'w-10',
    css: { width: '2.5rem' }
  },
  {
    tw: 'w-12',
    css: { width: '3rem' }
  },
  {
    tw: 'w-16',
    css: { width: '4rem' }
  },
  {
    tw: 'w-20',
    css: { width: '5rem' }
  },
  {
    tw: 'w-24',
    css: { width: '6rem' }
  },
  {
    tw: 'w-32',
    css: { width: '8rem' }
  },
  {
    tw: 'w-40',
    css: { width: '10rem' }
  },
  {
    tw: 'w-48',
    css: { width: '12rem' }
  },
  {
    tw: 'w-56',
    css: { width: '14rem' }
  },
  {
    tw: 'w-64',
    css: { width: '16rem' }
  },
  {
    tw: 'w-72',
    css: { width: '18rem' }
  },
  {
    tw: 'w-80',
    css: { width: '20rem' }
  },
  {
    tw: 'w-96',
    css: { width: '24rem' }
  },
  {
    tw: 'w-auto',
    css: { width: 'auto' }
  },
  {
    tw: 'w-full',
    css: { width: '100%' }
  },
  {
    tw: 'w-screen',
    css: { width: '100vw' }
  },
  {
    tw: 'w-min',
    css: { width: 'min-content' }
  },
  {
    tw: 'w-max',
    css: { width: 'max-content' }
  },

  // Height
  {
    tw: 'h-0',
    css: { height: '0px' }
  },
  {
    tw: 'h-1',
    css: { height: '0.25rem' }
  },
  {
    tw: 'h-2',
    css: { height: '0.5rem' }
  },
  {
    tw: 'h-3',
    css: { height: '0.75rem' }
  },
  {
    tw: 'h-4',
    css: { height: '1rem' }
  },
  {
    tw: 'h-5',
    css: { height: '1.25rem' }
  },
  {
    tw: 'h-6',
    css: { height: '1.5rem' }
  },
  {
    tw: 'h-8',
    css: { height: '2rem' }
  },
  {
    tw: 'h-10',
    css: { height: '2.5rem' }
  },
  {
    tw: 'h-12',
    css: { height: '3rem' }
  },
  {
    tw: 'h-16',
    css: { height: '4rem' }
  },
  {
    tw: 'h-20',
    css: { height: '5rem' }
  },
  {
    tw: 'h-24',
    css: { height: '6rem' }
  },
  {
    tw: 'h-32',
    css: { height: '8rem' }
  },
  {
    tw: 'h-40',
    css: { height: '10rem' }
  },
  {
    tw: 'h-48',
    css: { height: '12rem' }
  },
  {
    tw: 'h-56',
    css: { height: '14rem' }
  },
  {
    tw: 'h-64',
    css: { height: '16rem' }
  },
  {
    tw: 'h-72',
    css: { height: '18rem' }
  },
  {
    tw: 'h-80',
    css: { height: '20rem' }
  },
  {
    tw: 'h-96',
    css: { height: '24rem' }
  },
  {
    tw: 'h-auto',
    css: { height: 'auto' }
  },
  {
    tw: 'h-full',
    css: { height: '100%' }
  },
  {
    tw: 'h-screen',
    css: { height: '100vh' }
  },

  // Typography
  {
    tw: 'text-xs',
    css: { fontSize: '0.75rem', lineHeight: '1rem' }
  },
  {
    tw: 'text-sm',
    css: { fontSize: '0.875rem', lineHeight: '1.25rem' }
  },
  {
    tw: 'text-base',
    css: { fontSize: '1rem', lineHeight: '1.5rem' }
  },
  {
    tw: 'text-lg',
    css: { fontSize: '1.125rem', lineHeight: '1.75rem' }
  },
  {
    tw: 'text-xl',
    css: { fontSize: '1.25rem', lineHeight: '1.75rem' }
  },
  {
    tw: 'text-2xl',
    css: { fontSize: '1.5rem', lineHeight: '2rem' }
  },
  {
    tw: 'text-3xl',
    css: { fontSize: '1.875rem', lineHeight: '2.25rem' }
  },
  {
    tw: 'text-4xl',
    css: { fontSize: '2.25rem', lineHeight: '2.5rem' }
  },
  {
    tw: 'text-5xl',
    css: { fontSize: '3rem', lineHeight: '1' }
  },
  {
    tw: 'text-6xl',
    css: { fontSize: '3.75rem', lineHeight: '1' }
  },
  {
    tw: 'text-7xl',
    css: { fontSize: '4.5rem', lineHeight: '1' }
  },
  {
    tw: 'text-8xl',
    css: { fontSize: '6rem', lineHeight: '1' }
  },
  {
    tw: 'text-9xl',
    css: { fontSize: '8rem', lineHeight: '1' }
  },
  {
    tw: 'font-thin',
    css: { fontWeight: '100' }
  },
  {
    tw: 'font-extralight',
    css: { fontWeight: '200' }
  },
  {
    tw: 'font-light',
    css: { fontWeight: '300' }
  },
  {
    tw: 'font-normal',
    css: { fontWeight: '400' }
  },
  {
    tw: 'font-medium',
    css: { fontWeight: '500' }
  },
  {
    tw: 'font-semibold',
    css: { fontWeight: '600' }
  },
  {
    tw: 'font-bold',
    css: { fontWeight: '700' }
  },
  {
    tw: 'font-extrabold',
    css: { fontWeight: '800' }
  },
  {
    tw: 'font-black',
    css: { fontWeight: '900' }
  },
  {
    tw: 'italic',
    css: { fontStyle: 'italic' }
  },
  {
    tw: 'not-italic',
    css: { fontStyle: 'normal' }
  },
  {
    tw: 'uppercase',
    css: { textTransform: 'uppercase' }
  },
  {
    tw: 'lowercase',
    css: { textTransform: 'lowercase' }
  },
  {
    tw: 'capitalize',
    css: { textTransform: 'capitalize' }
  },
  {
    tw: 'normal-case',
    css: { textTransform: 'none' }
  },
  {
    tw: 'underline',
    css: { textDecorationLine: 'underline' }
  },
  {
    tw: 'line-through',
    css: { textDecorationLine: 'line-through' }
  },
  {
    tw: 'no-underline',
    css: { textDecorationLine: 'none' }
  },
  {
    tw: 'text-left',
    css: { textAlign: 'left' }
  },
  {
    tw: 'text-center',
    css: { textAlign: 'center' }
  },
  {
    tw: 'text-right',
    css: { textAlign: 'right' }
  },
  {
    tw: 'text-justify',
    css: { textAlign: 'justify' }
  },
  {
    tw: 'text-transparent',
    css: { color: 'transparent' }
  },
  {
    tw: 'text-current',
    css: { color: 'currentColor' }
  },

  // Colors (Text)
  {
    tw: 'text-black',
    css: { color: '#000000' }
  },
  {
    tw: 'text-white',
    css: { color: '#ffffff' }
  },
  {
    tw: 'text-gray-50',
    css: { color: '#f9fafb' }
  },
  {
    tw: 'text-gray-100',
    css: { color: '#f3f4f6' }
  },
  {
    tw: 'text-gray-200',
    css: { color: '#e5e7eb' }
  },
  {
    tw: 'text-gray-300',
    css: { color: '#d1d5db' }
  },
  {
    tw: 'text-gray-400',
    css: { color: '#9ca3af' }
  },
  {
    tw: 'text-gray-500',
    css: { color: '#6b7280' }
  },
  {
    tw: 'text-gray-600',
    css: { color: '#4b5563' }
  },
  {
    tw: 'text-gray-700',
    css: { color: '#374151' }
  },
  {
    tw: 'text-gray-800',
    css: { color: '#1f2937' }
  },
  {
    tw: 'text-gray-900',
    css: { color: '#111827' }
  },
  {
    tw: 'text-red-50',
    css: { color: '#fef2f2' }
  },
  {
    tw: 'text-red-100',
    css: { color: '#fee2e2' }
  },
  {
    tw: 'text-red-200',
    css: { color: '#fecaca' }
  },
  {
    tw: 'text-red-300',
    css: { color: '#fca5a5' }
  },
  {
    tw: 'text-red-400',
    css: { color: '#f87171' }
  },
  {
    tw: 'text-red-500',
    css: { color: '#ef4444' }
  },
  {
    tw: 'text-red-600',
    css: { color: '#dc2626' }
  },
  {
    tw: 'text-red-700',
    css: { color: '#b91c1c' }
  },
  {
    tw: 'text-red-800',
    css: { color: '#991b1b' }
  },
  {
    tw: 'text-red-900',
    css: { color: '#7f1d1d' }
  },
  {
    tw: 'text-blue-50',
    css: { color: '#eff6ff' }
  },
  {
    tw: 'text-blue-100',
    css: { color: '#dbeafe' }
  },
  {
    tw: 'text-blue-200',
    css: { color: '#bfdbfe' }
  },
  {
    tw: 'text-blue-300',
    css: { color: '#93c5fd' }
  },
  {
    tw: 'text-blue-400',
    css: { color: '#60a5fa' }
  },
  {
    tw: 'text-blue-500',
    css: { color: '#3b82f6' }
  },
  {
    tw: 'text-blue-600',
    css: { color: '#2563eb' }
  },
  {
    tw: 'text-blue-700',
    css: { color: '#1d4ed8' }
  },
  {
    tw: 'text-blue-800',
    css: { color: '#1e40af' }
  },
  {
    tw: 'text-blue-900',
    css: { color: '#1e3a8a' }
  },
  {
    tw: 'text-green-50',
    css: { color: '#f0fdf4' }
  },
  {
    tw: 'text-green-100',
    css: { color: '#dcfce7' }
  },
  {
    tw: 'text-green-200',
    css: { color: '#bbf7d0' }
  },
  {
    tw: 'text-green-300',
    css: { color: '#86efac' }
  },
  {
    tw: 'text-green-400',
    css: { color: '#4ade80' }
  },
  {
    tw: 'text-green-500',
    css: { color: '#22c55e' }
  },
  {
    tw: 'text-green-600',
    css: { color: '#16a34a' }
  },
  {
    tw: 'text-green-700',
    css: { color: '#15803d' }
  },
  {
    tw: 'text-green-800',
    css: { color: '#166534' }
  },
  {
    tw: 'text-green-900',
    css: { color: '#14532d' }
  },
  {
    tw: 'text-yellow-50',
    css: { color: '#fefce8' }
  },
  {
    tw: 'text-yellow-100',
    css: { color: '#fef9c3' }
  },
  {
    tw: 'text-yellow-200',
    css: { color: '#fef08a' }
  },
  {
    tw: 'text-yellow-300',
    css: { color: '#fde047' }
  },
  {
    tw: 'text-yellow-400',
    css: { color: '#facc15' }
  },
  {
    tw: 'text-yellow-500',
    css: { color: '#eab308' }
  },
  {
    tw: 'text-yellow-600',
    css: { color: '#ca8a04' }
  },
  {
    tw: 'text-yellow-700',
    css: { color: '#a16207' }
  },
  {
    tw: 'text-yellow-800',
    css: { color: '#854d0e' }
  },
  {
    tw: 'text-yellow-900',
    css: { color: '#713f12' }
  },
  {
    tw: 'text-purple-50',
    css: { color: '#faf5ff' }
  },
  {
    tw: 'text-purple-100',
    css: { color: '#f3e8ff' }
  },
  {
    tw: 'text-purple-200',
    css: { color: '#e9d5ff' }
  },
  {
    tw: 'text-purple-300',
    css: { color: '#d8b4fe' }
  },
  {
    tw: 'text-purple-400',
    css: { color: '#c084fc' }
  },
  {
    tw: 'text-purple-500',
    css: { color: '#a855f7' }
  },
  {
    tw: 'text-purple-600',
    css: { color: '#9333ea' }
  },
  {
    tw: 'text-purple-700',
    css: { color: '#7e22ce' }
  },
  {
    tw: 'text-purple-800',
    css: { color: '#6b21a8' }
  },
  {
    tw: 'text-purple-900',
    css: { color: '#581c87' }
  },
  {
    tw: 'text-pink-50',
    css: { color: '#fdf2f8' }
  },
  {
    tw: 'text-pink-100',
    css: { color: '#fce7f3' }
  },
  {
    tw: 'text-pink-200',
    css: { color: '#fbcfe8' }
  },
  {
    tw: 'text-pink-300',
    css: { color: '#f9a8d4' }
  },
  {
    tw: 'text-pink-400',
    css: { color: '#f472b6' }
  },
  {
    tw: 'text-pink-500',
    css: { color: '#ec4899' }
  },
  {
    tw: 'text-pink-600',
    css: { color: '#db2777' }
  },
  {
    tw: 'text-pink-700',
    css: { color: '#be185d' }
  },
  {
    tw: 'text-pink-800',
    css: { color: '#9d174d' }
  },
  {
    tw: 'text-pink-900',
    css: { color: '#831843' }
  },
  {
    tw: 'text-indigo-50',
    css: { color: '#eef2ff' }
  },
  {
    tw: 'text-indigo-100',
    css: { color: '#e0e7ff' }
  },
  {
    tw: 'text-indigo-200',
    css: { color: '#c7d2fe' }
  },
  {
    tw: 'text-indigo-300',
    css: { color: '#a5b4fc' }
  },
  {
    tw: 'text-indigo-400',
    css: { color: '#818cf8' }
  },
  {
    tw: 'text-indigo-500',
    css: { color: '#6366f1' }
  },
  {
    tw: 'text-indigo-600',
    css: { color: '#4f46e5' }
  },
  {
    tw: 'text-indigo-700',
    css: { color: '#4338ca' }
  },
  {
    tw: 'text-indigo-800',
    css: { color: '#3730a3' }
  },
  {
    tw: 'text-indigo-900',
    css: { color: '#312e81' }
  },

  // Background Colors
  {
    tw: 'bg-transparent',
    css: { backgroundColor: 'transparent' }
  },
  {
    tw: 'bg-current',
    css: { backgroundColor: 'currentColor' }
  },
  {
    tw: 'bg-black',
    css: { backgroundColor: '#000000' }
  },
  {
    tw: 'bg-white',
    css: { backgroundColor: '#ffffff' }
  },
  {
    tw: 'bg-gray-50',
    css: { backgroundColor: '#f9fafb' }
  },
  {
    tw: 'bg-gray-100',
    css: { backgroundColor: '#f3f4f6' }
  },
  {
    tw: 'bg-gray-200',
    css: { backgroundColor: '#e5e7eb' }
  },
  {
    tw: 'bg-gray-300',
    css: { backgroundColor: '#d1d5db' }
  },
  {
    tw: 'bg-gray-400',
    css: { backgroundColor: '#9ca3af' }
  },
  {
    tw: 'bg-gray-500',
    css: { backgroundColor: '#6b7280' }
  },
  {
    tw: 'bg-gray-600',
    css: { backgroundColor: '#4b5563' }
  },
  {
    tw: 'bg-gray-700',
    css: { backgroundColor: '#374151' }
  },
  {
    tw: 'bg-gray-800',
    css: { backgroundColor: '#1f2937' }
  },
  {
    tw: 'bg-gray-900',
    css: { backgroundColor: '#111827' }
  },
  {
    tw: 'bg-red-50',
    css: { backgroundColor: '#fef2f2' }
  },
  {
    tw: 'bg-red-100',
    css: { backgroundColor: '#fee2e2' }
  },
  {
    tw: 'bg-red-200',
    css: { backgroundColor: '#fecaca' }
  },