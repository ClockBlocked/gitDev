window.addEventListener("DOMContentLoaded", () => {

    // Load dependencies.js first
    const dependenciesScript = document.createElement('script');
    dependenciesScript.src = 'https://gitdev.wuaze.com/modules/dependencies.js';

    // Load storage.js
    const storageScript = document.createElement('script');
    storageScript.src = 'https://gitdev.wuaze.com/modules/storage.js';

    // Load router.js
    const routerScript = document.createElement('script');
    routerScript.src = 'https://gitdev.wuaze.com/modules/router.js';

    // Load pageUpdates.js
    const pageUpdatesScript = document.createElement('script');
    pageUpdatesScript.src = 'https://gitdev.wuaze.com/modules/pageUpdates.js';

    // Load overlays.js
    const overlaysScript = document.createElement('script');
    overlaysScript.src = 'https://gitdev.wuaze.com/modules/overlays.js';

    // Load core.js
    const coreScript = document.createElement('script');
    coreScript.src = 'https://gitdev.wuaze.com/modules/core.js';

    // Load listeners.js
    const listenersScript = document.createElement('script');
    listenersScript.src = 'https://gitdev.wuaze.com/modules/listeners.js';

    const scripts = [
        dependenciesScript,
        storageScript,
        routerScript,
        pageUpdatesScript,
        overlaysScript,
        coreScript,
        listenersScript
    ];

    let loadedCount = 0;

    function checkAllLoaded() {
        loadedCount++;
if (loadedCount === totalScripts) {
    setTimeout(() => {

        // Initialize sidebar AFTER all modules exist
        if (typeof SidebarManager !== "undefined" && SidebarManager.init) {
            SidebarManager.init();
        }

        // Your app-level initializer
        if (typeof initializeApp === "function") {
            initializeApp();
        }

    }, 50);
}
    }

    scripts.forEach(script => {
        script.onload = checkAllLoaded;
        script.onerror = () => {
            console.error("Failed to load script:", script.src);
            checkAllLoaded();
        };
        document.head.appendChild(script);
    });
});