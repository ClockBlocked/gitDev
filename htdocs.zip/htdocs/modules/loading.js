/**
 * GitHub-style loading progress bar
 *
 * A lightweight, flexible pure JavaScript module to add an animated loading progress bar to your site.
 * Closely mimics the style and behavior of GitHub's page load indicator.
 *
 * @module GitHubLoadingProgress
 * @version 1.0.0
 * @example
 * import LoadingProgress from './github-loading-progress.js';
 *
 * // Show the loader
 * LoadingProgress.show();
 *
 * // Simulate loading...
 * fetchData().then(() => {
 *   LoadingProgress.hide();
 * });
 *
 * // Configure options
 * LoadingProgress.config({
 *   color: '#ff0000',
 *   height: '5px',
 *   minimum: 20,
 *   maximum: 90
 * });
 */

// Loader styles
const loaderStyles = `
  .gh-progress {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 2.5px;
    z-index: 9999;
    background-color: #e1e4e8;
    transition: opacity 0.5s linear;
    opacity: 0;
    pointer-events: none;
  }
  
  .gh-progress.visible {
    opacity: 1;
    transition: opacity 0.3s ease-in;
  }
  
  .gh-progress-fill {
    display: block;
    height: 100%;
    width: 0;
    background-color: #0366d6;
    transition: width 0.5s ease-in-out;
  }
`;

const LoadingProgress = (() => {

  let progressElement = null;
  let fillElement = null;
  let hideTimeout = null;
  let progressInterval = null;
  let currentProgress = 0;

  // Default config
  let config = {
    color: '#1c7eec',
    height: '2.5px', 
    minimum: 0.08,
    maximum: 0.994,
    incrementPace: 'realistic'
  };

  /**
   * Initialize the progress bar and inject into DOM
   * @private
   */
  function init() {
    progressElement = document.createElement('div');
    progressElement.className = 'gh-progress';
    
    fillElement = document.createElement('div'); 
    fillElement.className = 'gh-progress-fill';
    
    progressElement.appendChild(fillElement);
    
    // Inject styles
    const styleElement = document.createElement('style');
    styleElement.innerHTML = loaderStyles;
    document.head.appendChild(styleElement);
    
    // Configure styles
    progressElement.style.height = config.height;
    fillElement.style.backgroundColor = config.color;
    
    document.body.appendChild(progressElement);
  }

  /**
   * Show the loading progress bar
   * @public
   */
  function show() {
    if (!progressElement) init();
    
    cleanup();
    currentProgress = 0;
    progressElement.classList.remove('hidden');  
    progressElement.classList.add('visible');
    
    if (config.incrementPace === 'realistic') {
      simulateRealisticLoad();
    } else if (config.incrementPace === 'linear') {
      simulateLinearLoad();
    } else {
      fillElement.style.width = `${config.minimum * 100}%`; 
    }
  }

  /**
   * Hide the loading progress bar
   * @public
   */
  function hide() {
    if (!progressElement) return;
    
    currentProgress = 100;
    fillElement.style.width = '100%';
    
    hideTimeout = setTimeout(() => {
      progressElement.classList.remove('visible');
      setTimeout(cleanup, 300);  
    }, 150);
  }

  /**
   * Clean up timeouts and intervals 
   * @private
   */
  function cleanup() {
    clearTimeout(hideTimeout);
    hideTimeout = null;
    
    clearInterval(progressInterval);
    progressInterval = null;
    
    progressElement.classList.add('hidden');
    progressElement.classList.remove('visible');
    
    fillElement.style.width = '0%';
    currentProgress = 0;
  }

  /**
   * Simulate realistic, non-linear progress
   * @private  
   */
  function simulateRealisticLoad() {
    const updateProgress = () => {
      if (currentProgress >= config.maximum * 100) {
        clearInterval(progressInterval);
        return;
      }
      
      let increment, delay;

      if (currentProgress < 60) {
        increment = Math.random() * 5 + 3;
        delay = Math.random() * 60 + 20;
      } else if (currentProgress < 90) {
        increment = Math.random() * 2 + 1;
        delay = Math.random() * 250 + 150;
      } else {
        increment = Math.random() * 0.5 + 0.3;  
        delay = Math.random() * 500 + 500;
      }

      currentProgress = Math.min(config.maximum * 100, currentProgress + increment);
      fillElement.style.width = `${currentProgress}%`;

      clearInterval(progressInterval);
      progressInterval = setTimeout(updateProgress, delay);
    };

    updateProgress();
  }

  /**
   * Simulate linear progress  
   * @private
   */
  function simulateLinearLoad() {
    const updateProgress = () => {
      currentProgress += 1;
      fillElement.style.width = `${currentProgress}%`;

      if (currentProgress < config.maximum * 100) {
        setTimeout(updateProgress, 16);
      }
    };

    updateProgress();
  }

  /**
   * Set configuration options
   * @public
   * @param {Object} options 
   * @param {string} [options.color] - Color of the progress bar (hex, rgb, hsl)
   * @param {string} [options.height] - Height/thickness of the bar (include unit, e.g. '5px')
   * @param {number} [options.minimum=0.08] - Minimum progress value (between 0-1)
   * @param {number} [options.maximum=0.994] - Maximum progress value (between 0-1)  
   * @param {string} [options.incrementPace='realistic'] - Progress animation style ('realistic' or 'linear')
   * @example  
   * LoadingProgress.config({
   *   color: 'red',  
   *   height: '5px',
   *   minimum: 0.2,
   *   incrementPace: 'linear'
   * })
   */
  function config(options = {}) {
    config = { ...config, ...options };

    if (progressElement) {
      progressElement.style.height = config.height;
      fillElement.style.backgroundColor = config.color;
    }
  }

  /**
   * Check if the loading progress is currently visible
   * @public
   * @returns {boolean}
   */
  function isVisible() {
    return progressElement && !progressElement.classList.contains('hidden');
  }

  return {
    config,
    show,
    hide,
    isVisible  
  };

})();

export default LoadingProgress;